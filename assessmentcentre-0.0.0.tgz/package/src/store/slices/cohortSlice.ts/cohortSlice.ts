// src/store/slices/cohortSlice.ts

import {
  collection,
  getDocs,
  deleteDoc,
  query,
  orderBy,
  doc,
  writeBatch,
} from "firebase/firestore";
import { db } from "../../../lib/firebase";
import type { Cohort } from "../../../types";
import type { StateCreator } from "zustand";

// ─── TYPES ────────────────────────────────────────────────────────────────────

export interface CohortSlice {
  cohorts: Cohort[];
  cohortsLoading: boolean;
  cohortsError: string | null;
  fetchCohorts: (force?: boolean) => Promise<void>;
  addCohort: (cohort: Omit<Cohort, "id" | "createdAt">) => Promise<void>;
  updateCohort: (
    id: string,
    updates: Partial<Cohort>,
    reasons?: { facilitator?: string; assessor?: string; moderator?: string },
  ) => Promise<void>;
  deleteCohort: (id: string) => Promise<void>;
}

// ─── IMPLEMENTATION ───────────────────────────────────────────────────────────

export const createCohortSlice: StateCreator<
  any,
  [["zustand/immer", never]],
  [],
  CohortSlice
> = (set, get, _) => ({
  cohorts: [],
  cohortsLoading: false,
  cohortsError: null,

  // fetchCohorts: async (force = false) => {
  //   const { cohorts } = get();
  //   if (!force && cohorts.length > 0) return;

  //   set((state: any) => {
  //     state.cohortsLoading = true;
  //     state.cohortsError = null;
  //   });

  //   try {
  //     const q = query(collection(db, "cohorts"), orderBy("name"));
  //     const snapshot = await getDocs(q);
  //     const list = snapshot.docs.map(
  //       (doc) => ({ id: doc.id, ...doc.data() }) as Cohort,
  //     );

  //     set((state: any) => {
  //       state.cohorts = list;
  //       state.cohortsLoading = false;
  //     });
  //   } catch (systemError: any) {
  //     console.error("Failed to fetch cohorts:", systemError);
  //     set((state: any) => {
  //       state.cohortsLoading = false;
  //       state.cohortsError = systemError.message;
  //     });
  //   }
  // },
  fetchCohorts: async (force = false) => {
    const { cohorts } = get();

    if (!force && cohorts.length > 0) {
      console.log(
        "[DEBUG useStore] Cohorts already in memory. Skipping fetch.",
      );
      return;
    }

    set((state: any) => {
      state.cohortsLoading = true;
      state.cohortsError = null;
    });

    try {
      console.log("[DEBUG useStore] Fetching cohorts from Firestore...");
      const start = Date.now();

      const q = query(collection(db, "cohorts"), orderBy("name"));
      const snapshot = await getDocs(q);
      const list = snapshot.docs.map(
        (doc) => ({ id: doc.id, ...doc.data() }) as Cohort,
      );

      console.log(
        `[DEBUG useStore] Fetched ${list.length} cohorts in ${Date.now() - start}ms.`,
      );

      set((state: any) => {
        state.cohorts = list;
        state.cohortsLoading = false;
      });
    } catch (systemError: any) {
      console.error("Failed to fetch cohorts:", systemError);
      set((state: any) => {
        state.cohortsLoading = false;
        state.cohortsError = systemError.message;
      });
    }
  },

  addCohort: async (newCohort) => {
    const batch = writeBatch(db);
    const timestamp = new Date().toISOString();

    // 1. Setup Cohort Document
    const cohortRef = doc(collection(db, "cohorts"));
    const cohortId = cohortRef.id;
    const cohortData = {
      ...newCohort,
      id: cohortId,
      createdAt: timestamp,
      isArchived: false,
    };

    batch.set(cohortRef, cohortData);

    // 2. THE HANDSHAKE: Sync Learners & Create Enrollment Ledger
    if (newCohort.learnerIds && newCohort.learnerIds.length > 0) {
      newCohort.learnerIds.forEach((learnerId: string) => {
        // A. Update the learner profile pointer (fast UI loading)
        // learnerId is now strictly their idNumber
        const learnerRef = doc(db, "learners", learnerId);
        batch.set(
          learnerRef,
          { cohortId: cohortId, updatedAt: timestamp },
          { merge: true },
        );

        // B. Create the official Enrollment Ledger document
        // Composite ID guarantees no double-enrollment in the same exact class
        const enrollmentId = `${cohortId}_${learnerId}`;
        const enrollmentRef = doc(db, "enrollments", enrollmentId);
        batch.set(
          enrollmentRef,
          {
            id: enrollmentId,
            learnerId: learnerId,
            cohortId: cohortId,
            programmeId: newCohort.programmeId || "", // Strict validation mapping
            status: "active",
            enrolledAt: timestamp,
            assignedBy: "System",
            isArchived: false,
          },
          { merge: true },
        );

        // C. Clean up any corrupted legacy "Unassigned" records
        batch.delete(doc(db, "enrollments", `Unassigned_${learnerId}`));
      });
    }

    try {
      await batch.commit();

      set((state: any) => {
        state.cohorts.push(cohortData);
        if (state.learners) {
          state.learners.forEach((l: any) => {
            if (newCohort.learnerIds?.includes(l.id)) {
              l.cohortId = cohortId;
            }
          });
        }
      });
    } catch (systemError) {
      console.error("Failed to add cohort and sync learners:", systemError);
      throw systemError;
    }
  },

  updateCohort: async (id, updates, reasons) => {
    const { cohorts } = get();
    const currentCohort = cohorts.find((c: any) => c.id === id);

    // Prevent acting on non-existent data
    if (!currentCohort) {
      throw new ReferenceError(
        "Update Failed: Target Cohort not found in local state.",
      );
    }

    const batch = writeBatch(db);
    const timestamp = new Date().toISOString();
    const adminId = "System";

    const oldIds = currentCohort.learnerIds || [];

    // QCTO STAFF HISTORY LOGIC (Audit Trail) ---
    let newHistory = [...(currentCohort.staffHistory || [])];

    const handleRoleChange = (
      role: "facilitator" | "assessor" | "moderator",
      newId: string | undefined,
      oldId: string,
      reason?: string,
    ) => {
      if (newId && newId !== oldId) {
        newHistory = newHistory.map((h) => {
          if (h.role === role && h.staffId === oldId && h.removedAt === null) {
            return { ...h, removedAt: timestamp };
          }
          return h;
        });

        newHistory.push({
          staffId: newId,
          role: role,
          assignedAt: timestamp,
          removedAt: null,
          assignedBy: adminId,
          changeReason: reason || "Role Update",
        });
      }
    };

    if (updates.facilitatorId)
      handleRoleChange(
        "facilitator",
        updates.facilitatorId,
        currentCohort.facilitatorId,
        reasons?.facilitator,
      );
    if (updates.assessorId)
      handleRoleChange(
        "assessor",
        updates.assessorId,
        currentCohort.assessorId,
        reasons?.assessor,
      );
    if (updates.moderatorId)
      handleRoleChange(
        "moderator",
        updates.moderatorId,
        currentCohort.moderatorId,
        reasons?.moderator,
      );

    // --- 2. LEARNER SYNC LOGIC (The Ledger Handshake) ---
    if (updates.learnerIds) {
      const newIds = updates.learnerIds;

      const added = newIds.filter((lid: string) => !oldIds.includes(lid));
      const removed = oldIds.filter((lid: string) => !newIds.includes(lid));

      added.forEach((lid: string) => {
        // Set fast-pointer on Learner profile to active class
        batch.set(
          doc(db, "learners", lid),
          { cohortId: id, updatedAt: timestamp },
          { merge: true },
        );

        // Create the new active Enrollment Ledger entry
        const enrollmentId = `${id}_${lid}`;
        batch.set(
          doc(db, "enrollments", enrollmentId),
          {
            id: enrollmentId,
            learnerId: lid,
            cohortId: id,
            programmeId: currentCohort.programmeId || "",
            status: "active",
            enrolledAt: timestamp,
            assignedBy: "System",
            isArchived: false,
          },
          { merge: true },
        );

        // Clean up legacy ghost
        batch.delete(doc(db, "enrollments", `Unassigned_${lid}`));
      });

      removed.forEach((lid: string) => {
        // Remove fast-pointer from Learner profile (Move to Dormant State)
        batch.set(
          doc(db, "learners", lid),
          { cohortId: "", status: "dropped", updatedAt: timestamp }, // STRICT EMPTY STRING
          { merge: true },
        );

        // Close out the Enrollment Ledger entry (DO NOT DELETE!)
        // Marks them as dropped so we maintain an audit trail
        const enrollmentId = `${id}_${lid}`;
        batch.set(
          doc(db, "enrollments", enrollmentId),
          {
            status: "dropped",
            exitDate: timestamp,
            exitReason: "Removed via Class Roster Management",
            updatedAt: timestamp,
          },
          { merge: true },
        );
      });
    }

    // --- DATABASE UPDATE ---
    const cohortRef = doc(db, "cohorts", id);
    const finalPayload = {
      ...currentCohort,
      ...updates,
      staffHistory: newHistory,
      updatedAt: timestamp,
    };

    const { id: _, ...dataToSave } = finalPayload;

    batch.set(cohortRef, dataToSave, { merge: true });

    try {
      await batch.commit();

      // --- LOCAL STATE UPDATE ---
      set((state: any) => {
        const idx = state.cohorts.findIndex((c: any) => c.id === id);
        if (idx !== -1) {
          state.cohorts[idx] = finalPayload;
        }

        if (state.learners && updates.learnerIds) {
          state.learners.forEach((l: any) => {
            if (updates.learnerIds?.includes(l.id)) {
              l.cohortId = id;
              l.status = "active";
            } else if (oldIds.includes(l.id)) {
              // NO FALLBACKS: Force them into Dormant status
              l.cohortId = "";
              l.status = "dropped";
            }
          });
        }
      });
    } catch (systemError) {
      console.error("Critical Sync Failure on Cohort Update:", systemError);
      throw systemError;
    }
  },

  deleteCohort: async (id) => {
    try {
      await deleteDoc(doc(db, "cohorts", id));
      set((state: any) => {
        state.cohorts = state.cohorts.filter((c: Cohort) => c.id !== id);
      });
    } catch (systemError) {
      console.error("Failed to delete cohort", systemError);
      throw systemError;
    }
  },
});
