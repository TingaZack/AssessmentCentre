import React, { useMemo, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
    Users, ShieldCheck, MapPin, GraduationCap, BookOpen,
    Layers, AlertTriangle, Scale, LayoutDashboard, FileSignature, MonitorPlay
} from 'lucide-react';
import {
    BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer,
    PieChart, Pie, Cell, Legend
} from 'recharts';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../../../lib/firebase';
import { useStore } from '../../../store/useStore';
import './DashboardOverview.css';
import StatCard from '../../common/StatCard/StatCard';

export const DashboardOverview: React.FC = () => {
    // 1. Destructure fetch actions to guarantee data loads on direct navigation
    const { learners, cohorts, programmes, settings, user, fetchLearners, fetchCohorts, fetchProgrammes } = useStore();
    const navigate = useNavigate();

    const [pendingAppealsCount, setPendingAppealsCount] = useState(0);
    const [pendingGradingCount, setPendingGradingCount] = useState(0);
    const [liveClassesCount, setLiveClassesCount] = useState(0);

    // ─── INITIALIZE GLOBAL STORE DATA ───
    useEffect(() => {
        if (learners.length === 0 && fetchLearners) fetchLearners();
        if (cohorts.length === 0 && fetchCohorts) fetchCohorts();
        if (programmes.length === 0 && fetchProgrammes) fetchProgrammes();
    }, []);

    // ─── FETCH LIVE ACTIONABLE METRICS ───
    useEffect(() => {
        const fetchLiveMetrics = async () => {
            try {
                // 1. Fetch Appeals
                const appealsSnap = await getDocs(query(collection(db, 'learner_submissions'), where('status', '==', 'appealed')));
                setPendingAppealsCount(appealsSnap.size);

                // 2. Fetch Pending Grading (Assessments submitted but not yet graded)
                const gradingSnap = await getDocs(query(collection(db, 'learner_submissions'), where('status', '==', 'submitted')));
                setPendingGradingCount(gradingSnap.size);

                // 3. Fetch Live Kiosk Sessions for Today
                const todayStr = new Date().toISOString().split('T')[0];
                const liveSnap = await getDocs(query(
                    collection(db, 'kiosk_sessions'),
                    where('date', '==', todayStr),
                    where('status', '==', 'active')
                ));
                setLiveClassesCount(liveSnap.size);
            } catch (err) {
                console.error("Failed to fetch live admin metrics:", err);
            }
        };
        fetchLiveMetrics();
    }, []);

    // ─── CORE ACADEMIC KPIs ───
    const activeLearners = learners.filter(l => !l.isArchived);
    const totalEnrollments = activeLearners.length;
    const securedCertificates = activeLearners.filter(l => l.isBlockchainVerified).length;
    const eisaReadyCount = activeLearners.filter(l => l.eisaAdmission).length;

    // ─── SYSTEM THROUGHPUT ───
    const activeProgrammesCount = programmes.filter(p => !p.isArchived).length;

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    let upcomingCohorts = 0;
    let ongoingCohorts = 0;
    let concludedCohorts = 0;

    cohorts.filter(c => !c.isArchived).forEach(c => {
        const startDate = new Date(c.startDate);
        const endDate = new Date(c.endDate);
        if (startDate > today) upcomingCohorts++;
        else if (endDate < today) concludedCohorts++;
        else ongoingCohorts++;
    });

    const activeCampusIds = new Set(cohorts.filter(c => !c.isArchived).map(c => c.campusId).filter(Boolean));
    const activeCampusesCount = activeCampusIds.size;

    // ─── AT-RISK & QA INTELLIGENCE ───
    const atRiskLearnersCount = useMemo(() => {
        let count = 0;
        activeLearners.forEach(l => {
            if (l.eisaAdmission) return;
            let hasNYC = false;
            const checkNYC = (mod: any) => {
                const s = mod.status?.toLowerCase();
                if (s === 'not yet competent' || s === 'nyc' || s === 'fail') hasNYC = true;
            };
            l.knowledgeModules?.forEach(checkNYC);
            l.practicalModules?.forEach(checkNYC);
            l.workExperienceModules?.forEach(checkNYC);

            let isOverdue = false;
            if (l.trainingEndDate) {
                const parts = l.trainingEndDate.split('-');
                if (parts.length === 3) {
                    const isYearFirst = parts[0].length === 4;
                    const endDate = isYearFirst
                        ? new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]))
                        : new Date(Number(parts[2]), Number(parts[1]) - 1, Number(parts[0]));
                    if (endDate < today) isOverdue = true;
                }
            }
            if (hasNYC || isOverdue) count++;
        });
        return count;
    }, [activeLearners, today]);

    // ─── CHART DATA PREPARATION ───
    const campusData = useMemo(() => {
        if (!settings?.campuses || settings.campuses.length === 0) return [];
        const counts: Record<string, number> = {};
        settings.campuses.forEach(c => { counts[c.id] = 0; });
        activeLearners.forEach(learner => {
            const cohort = cohorts.find(c => c.id === learner.cohortId);
            const campusId = learner.campusId || cohort?.campusId;
            if (campusId && counts[campusId] !== undefined) {
                counts[campusId] += 1;
            } else {
                const defaultCampus = settings.campuses.find(c => c.isDefault);
                if (defaultCampus) counts[defaultCampus.id] += 1;
            }
        });
        return settings.campuses.map(c => ({
            name: c.name.replace('Campus', '').replace('Hub', '').trim(),
            learners: counts[c.id]
        })).filter(c => c.learners > 0);
    }, [activeLearners, cohorts, settings]);

    const assessmentData = useMemo(() => {
        const stats = {
            Knowledge: { Competent: 0, NYC: 0, InProgress: 0 },
            Practical: { Competent: 0, NYC: 0, InProgress: 0 },
            Workplace: { Competent: 0, NYC: 0, InProgress: 0 }
        };
        const categorize = (status: string, category: 'Knowledge' | 'Practical' | 'Workplace') => {
            const s = status?.toLowerCase() || '';
            if (s === 'competent' || s === 'c' || s === 'pass') stats[category].Competent += 1;
            else if (s === 'not yet competent' || s === 'nyc' || s === 'fail') stats[category].NYC += 1;
            else stats[category].InProgress += 1;
        };
        activeLearners.forEach(l => {
            l.knowledgeModules?.forEach(m => categorize(m.status, 'Knowledge'));
            l.practicalModules?.forEach(m => categorize(m.status, 'Practical'));
            l.workExperienceModules?.forEach(m => categorize(m.status, 'Workplace'));
        });
        return [
            { name: 'Knowledge', ...stats.Knowledge },
            { name: 'Practical', ...stats.Practical },
            { name: 'Workplace', ...stats.Workplace }
        ];
    }, [activeLearners]);

    const cohortLifecycleData = [
        { name: 'Ongoing Classes', value: ongoingCohorts, color: 'var(--mlab-blue)' },
        { name: 'Concluded Classes', value: concludedCohorts, color: 'var(--mlab-green)' },
        { name: 'Upcoming Classes', value: upcomingCohorts, color: '#8b5cf6' }
    ].filter(d => d.value > 0);

    const web3Data = [
        { name: 'Secured on Blockchain', value: securedCertificates, color: 'var(--mlab-green)' },
        { name: 'Pending Mint', value: totalEnrollments - securedCertificates, color: '#f59e0b' }
    ].filter(d => d.value > 0);

    const tooltipStyle = {
        borderRadius: '8px',
        border: '1px solid var(--mlab-border)',
        boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)',
        fontFamily: 'var(--font-body)',
        fontSize: '0.82rem',
    };

    return (
        <div className="wm-root animate-fade-in" style={{ paddingBottom: '2rem' }}>

            {/* ── PAGE HEADER ── */}
            <div className="wm-page-header">
                <div className="wm-page-header__left">
                    <div className="wm-page-header__icon"><LayoutDashboard size={22} /></div>
                    <div>
                        <h1 className="wm-page-header__title">System Overview</h1>
                        <p className="wm-page-header__desc">High-level insights into academic performance, enrollments, and real-time operations.</p>
                    </div>
                </div>
            </div>

            {/* ── ACTION REQUIRED (URGENT KPIs) ── */}
            <h3 style={{ fontSize: '0.9rem', color: 'var(--mlab-grey)', textTransform: 'uppercase', letterSpacing: '0.05em', margin: '0 0 1rem 4px' }}>Action & Operations</h3>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '1.25rem', marginBottom: '2rem' }}>
                <StatCard
                    icon={<FileSignature size={20} />}
                    title="Pending Grading"
                    value={pendingGradingCount}
                    borderColor={pendingGradingCount > 0 ? "#f59e0b" : "var(--mlab-green)"}
                    onClick={() => navigate('/assessments')}
                    hoverable
                />
                <StatCard
                    icon={<Scale size={20} />}
                    title="Active Appeals"
                    value={pendingAppealsCount}
                    borderColor={pendingAppealsCount > 0 ? "var(--mlab-red)" : "var(--mlab-green)"}
                    onClick={() => navigate('/moderation')}
                    hoverable
                />
                <StatCard
                    icon={<MonitorPlay size={20} />}
                    title="Live Classes Today"
                    value={liveClassesCount}
                    borderColor={liveClassesCount > 0 ? "var(--mlab-blue)" : "var(--mlab-grey-light)"}
                    onClick={() => navigate('/attendance')}
                    hoverable
                />
            </div>

            {/* ── SYSTEM THROUGHPUT ── */}
            <h3 style={{ fontSize: '0.9rem', color: 'var(--mlab-grey)', textTransform: 'uppercase', letterSpacing: '0.05em', margin: '0 0 1rem 4px' }}>Capacity & Throughput</h3>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '1.25rem', marginBottom: '2rem' }}>
                <StatCard icon={<BookOpen size={20} />} title="Active Qualifications" value={activeProgrammesCount} borderColor="var(--mlab-blue)" />
                <StatCard icon={<Layers size={20} />} title="Active Cohorts" value={ongoingCohorts} borderColor="#8b5cf6" />
                <StatCard icon={<Users size={20} />} title="Total Enrollments" value={totalEnrollments} borderColor="var(--mlab-blue)" />
                <StatCard icon={<MapPin size={20} />} title="Active Campuses" value={activeCampusesCount} borderColor="#f59e0b" />
            </div>

            {/* ── ACADEMIC QA & BLOCKCHAIN ── */}
            <h3 style={{ fontSize: '0.9rem', color: 'var(--mlab-grey)', textTransform: 'uppercase', letterSpacing: '0.05em', margin: '0 0 1rem 4px' }}>Quality Assurance & Certification</h3>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '1.25rem', marginBottom: '2rem' }}>
                <StatCard icon={<GraduationCap size={20} />} title="EISA Admitted (Ready)" value={eisaReadyCount} borderColor="var(--mlab-green)" />
                <StatCard icon={<AlertTriangle size={20} />} title="At-Risk Learners" value={atRiskLearnersCount} borderColor="var(--mlab-red)" />
                <StatCard icon={<ShieldCheck size={20} />} title="Web3 Certificates Issued" value={securedCertificates} borderColor="#8b5cf6" />
            </div>

            {/* ── CHARTS ── */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(450px, 1fr))', gap: '1.25rem' }}>

                {/* Formative Assessment Health */}
                <div className="wm-card">
                    <div className="wm-card__header">
                        <h3 className="wm-card__name" style={{ fontSize: '0.9rem' }}>Formative Assessment Health</h3>
                    </div>
                    <div style={{ padding: '1rem 1.1rem', height: '320px' }}>
                        <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={assessmentData} margin={{ top: 5, right: 30, left: -20, bottom: 5 }}>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--mlab-border)" />
                                <XAxis dataKey="name" tick={{ fontSize: 12, fill: 'var(--mlab-grey)', fontFamily: 'var(--font-body)' }} axisLine={false} tickLine={false} />
                                <YAxis tick={{ fontSize: 12, fill: 'var(--mlab-grey)', fontFamily: 'var(--font-body)' }} axisLine={false} tickLine={false} />
                                <RechartsTooltip cursor={{ fill: 'var(--mlab-bg)' }} contentStyle={tooltipStyle} />
                                <Legend verticalAlign="top" height={36} iconType="circle" wrapperStyle={{ fontSize: '12px', fontFamily: 'var(--font-body)' }} />
                                <Bar dataKey="Competent" stackId="a" fill="var(--mlab-green)" radius={[0, 0, 4, 4]} />
                                <Bar dataKey="InProgress" stackId="a" fill="var(--mlab-blue)" name="In Progress" />
                                <Bar dataKey="NYC" stackId="a" fill="var(--mlab-red)" name="Not Yet Competent" radius={[4, 4, 0, 0]} />
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                </div>

                {/* Enrollments by Location */}
                <div className="wm-card">
                    <div className="wm-card__header">
                        <h3 className="wm-card__name" style={{ fontSize: '0.9rem' }}>Enrollments by Location</h3>
                    </div>
                    <div style={{ padding: '1rem 1.1rem', height: '320px' }}>
                        {campusData.length === 0 ? (
                            <div style={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--mlab-grey-light)', fontStyle: 'italic', fontSize: '0.85rem' }}>
                                No active enrollments assigned to campuses.
                            </div>
                        ) : (
                            <ResponsiveContainer width="100%" height="100%">
                                <BarChart data={campusData} margin={{ top: 5, right: 30, left: -20, bottom: 5 }}>
                                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--mlab-border)" />
                                    <XAxis dataKey="name" tick={{ fontSize: 12, fill: 'var(--mlab-grey)', fontFamily: 'var(--font-body)' }} axisLine={false} tickLine={false} />
                                    <YAxis tick={{ fontSize: 12, fill: 'var(--mlab-grey)', fontFamily: 'var(--font-body)' }} axisLine={false} tickLine={false} />
                                    <RechartsTooltip cursor={{ fill: 'var(--mlab-bg)' }} contentStyle={tooltipStyle} />
                                    <Bar dataKey="learners" fill="#8b5cf6" radius={[4, 4, 0, 0]} maxBarSize={50} name="Active Learners" />
                                </BarChart>
                            </ResponsiveContainer>
                        )}
                    </div>
                </div>

                {/* Cohort Lifecycle */}
                <div className="wm-card">
                    <div className="wm-card__header">
                        <h3 className="wm-card__name" style={{ fontSize: '0.9rem' }}>Cohort Lifecycle</h3>
                    </div>
                    <div style={{ padding: '1rem 1.1rem', height: '320px' }}>
                        {cohortLifecycleData.length === 0 ? (
                            <div style={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--mlab-grey-light)', fontStyle: 'italic', fontSize: '0.85rem' }}>
                                No active cohorts found.
                            </div>
                        ) : (
                            <ResponsiveContainer width="100%" height="100%">
                                <PieChart>
                                    <Pie data={cohortLifecycleData} cx="50%" cy="45%" innerRadius={70} outerRadius={100} paddingAngle={2} dataKey="value">
                                        {cohortLifecycleData.map((entry, index) => (
                                            <Cell key={`cell-${index}`} fill={entry.color} />
                                        ))}
                                    </Pie>
                                    <RechartsTooltip contentStyle={tooltipStyle} />
                                    <Legend verticalAlign="bottom" height={36} iconType="circle" wrapperStyle={{ fontFamily: 'var(--font-body)' }} />
                                </PieChart>
                            </ResponsiveContainer>
                        )}
                    </div>
                </div>

                {/* Certification Status */}
                <div className="wm-card">
                    <div className="wm-card__header">
                        <h3 className="wm-card__name" style={{ fontSize: '0.9rem' }}>Certification Status</h3>
                    </div>
                    <div style={{ padding: '1rem 1.1rem', height: '320px' }}>
                        {totalEnrollments === 0 ? (
                            <div style={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--mlab-grey-light)', fontStyle: 'italic', fontSize: '0.85rem' }}>
                                No enrollments to certify yet.
                            </div>
                        ) : (
                            <ResponsiveContainer width="100%" height="100%">
                                <PieChart>
                                    <Pie data={web3Data} cx="50%" cy="45%" innerRadius={70} outerRadius={100} paddingAngle={2} dataKey="value">
                                        {web3Data.map((entry, index) => (
                                            <Cell key={`cell-${index}`} fill={entry.color} />
                                        ))}
                                    </Pie>
                                    <RechartsTooltip contentStyle={tooltipStyle} />
                                    <Legend verticalAlign="bottom" height={36} iconType="circle" wrapperStyle={{ fontFamily: 'var(--font-body)' }} />
                                </PieChart>
                            </ResponsiveContainer>
                        )}
                    </div>
                </div>

            </div>
        </div>
    );
};



// // src/components/views/DashboardOverview/DashboardOverview.tsx

// import React, { useMemo, useState, useEffect } from 'react';
// import { useNavigate } from 'react-router-dom';
// import { Users, ShieldCheck, MapPin, GraduationCap, BookOpen, Layers, AlertTriangle, Scale, LayoutDashboard } from 'lucide-react';
// import {
//     BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer,
//     PieChart, Pie, Cell, Legend
// } from 'recharts';
// import { collection, query, where, getDocs } from 'firebase/firestore';
// import { db } from '../../../lib/firebase';
// import { useStore } from '../../../store/useStore';
// // import '../../admin/WorkplacesManager/WorkplacesManager.css';
// import './DashboardOverview.css';
// import StatCard from '../../common/StatCard/StatCard';

// // // ─── LOCAL STAT CARD (Reusing wm-card styles) ───
// // const DashboardStatCard = ({ title, value, icon, borderColor, onClick, hoverable }: any) => (
// //     <div
// //         className="wm-card"
// //         onClick={onClick}
// //         style={{
// //             borderTopColor: borderColor || 'var(--mlab-blue)',
// //             cursor: onClick ? 'pointer' : 'default',
// //             transform: hoverable ? undefined : 'none',
// //             transition: 'transform 0.2s, box-shadow 0.2s',
// //             height: '100%'
// //         }}
// //         onMouseEnter={e => {
// //             if (hoverable) {
// //                 e.currentTarget.style.transform = 'translateY(-3px)';
// //                 e.currentTarget.style.boxShadow = '0 8px 20px rgba(0,0,0,0.08)';
// //             }
// //         }}
// //         onMouseLeave={e => {
// //             if (hoverable) {
// //                 e.currentTarget.style.transform = 'none';
// //                 e.currentTarget.style.boxShadow = '0 2px 8px rgba(7, 63, 78, 0.05)';
// //             }
// //         }}
// //     >
// //         <div className="wm-card__header" style={{ paddingBottom: '0.5rem' }}>
// //             <h3 className="wm-card__name" style={{ fontSize: '0.85rem', color: 'var(--mlab-grey)' }}>{title}</h3>
// //             <div style={{ color: borderColor || 'var(--mlab-blue)', opacity: 0.8 }}>{icon}</div>
// //         </div>
// //         <div style={{ padding: '0 1.1rem 1.1rem', fontSize: '2.2rem', fontWeight: 'bold', color: 'var(--mlab-blue)', fontFamily: 'var(--font-heading)' }}>
// //             {value}
// //         </div>
// //     </div>
// // );

// export const DashboardOverview: React.FC = () => {
//     const { learners, cohorts, programmes, settings, user } = useStore();
//     const navigate = useNavigate();

//     // ─── CORE ACADEMIC KPIs ───
//     const activeLearners = learners.filter(l => !l.isArchived);
//     const totalEnrollments = activeLearners.length;
//     const securedCertificates = activeLearners.filter(l => l.isBlockchainVerified).length;
//     const eisaReadyCount = activeLearners.filter(l => l.eisaAdmission).length;

//     // ─── SYSTEM THROUGHPUT ───
//     const activeProgrammesCount = programmes.filter(p => !p.isArchived).length;

//     const today = new Date();
//     today.setHours(0, 0, 0, 0);

//     let upcomingCohorts = 0;
//     let ongoingCohorts = 0;
//     let concludedCohorts = 0;

//     cohorts.filter(c => !c.isArchived).forEach(c => {
//         const startDate = new Date(c.startDate);
//         const endDate = new Date(c.endDate);
//         if (startDate > today) upcomingCohorts++;
//         else if (endDate < today) concludedCohorts++;
//         else ongoingCohorts++;
//     });

//     const activeCampusIds = new Set(cohorts.filter(c => !c.isArchived).map(c => c.campusId).filter(Boolean));
//     const activeCampusesCount = activeCampusIds.size;

//     // ─── AT-RISK & QA INTELLIGENCE ───
//     const atRiskLearnersCount = useMemo(() => {
//         let count = 0;
//         activeLearners.forEach(l => {
//             if (l.eisaAdmission) return;
//             let hasNYC = false;
//             const checkNYC = (mod: any) => {
//                 const s = mod.status?.toLowerCase();
//                 if (s === 'not yet competent' || s === 'nyc' || s === 'fail') hasNYC = true;
//             };
//             l.knowledgeModules?.forEach(checkNYC);
//             l.practicalModules?.forEach(checkNYC);
//             l.workExperienceModules?.forEach(checkNYC);

//             let isOverdue = false;
//             if (l.trainingEndDate) {
//                 const parts = l.trainingEndDate.split('-');
//                 if (parts.length === 3) {
//                     const isYearFirst = parts[0].length === 4;
//                     const endDate = isYearFirst
//                         ? new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]))
//                         : new Date(Number(parts[2]), Number(parts[1]) - 1, Number(parts[0]));
//                     if (endDate < today) isOverdue = true;
//                 }
//             }
//             if (hasNYC || isOverdue) count++;
//         });
//         return count;
//     }, [activeLearners, today]);

//     // Fetch global active appeals count
//     const [pendingAppealsCount, setPendingAppealsCount] = useState(0);
//     useEffect(() => {
//         const fetchAppealsCount = async () => {
//             try {
//                 const snap = await getDocs(query(
//                     collection(db, 'learner_submissions'),
//                     where('status', '==', 'appealed')
//                 ));
//                 setPendingAppealsCount(snap.size);
//             } catch (err) {
//                 console.error("Failed to fetch pending appeals count:", err);
//             }
//         };
//         fetchAppealsCount();
//     }, []);

//     // ─── CHART DATA ───
//     const campusData = useMemo(() => {
//         if (!settings?.campuses || settings.campuses.length === 0) return [];
//         const counts: Record<string, number> = {};
//         settings.campuses.forEach(c => { counts[c.id] = 0; });
//         activeLearners.forEach(learner => {
//             const cohort = cohorts.find(c => c.id === learner.cohortId);
//             const campusId = learner.campusId || cohort?.campusId;
//             if (campusId && counts[campusId] !== undefined) {
//                 counts[campusId] += 1;
//             } else {
//                 const defaultCampus = settings.campuses.find(c => c.isDefault);
//                 if (defaultCampus) counts[defaultCampus.id] += 1;
//             }
//         });
//         return settings.campuses.map(c => ({
//             name: c.name.replace('Campus', '').replace('Hub', '').trim(),
//             learners: counts[c.id]
//         })).filter(c => c.learners > 0);
//     }, [activeLearners, cohorts, settings]);

//     const assessmentData = useMemo(() => {
//         const stats = {
//             Knowledge: { Competent: 0, NYC: 0, InProgress: 0 },
//             Practical: { Competent: 0, NYC: 0, InProgress: 0 },
//             Workplace: { Competent: 0, NYC: 0, InProgress: 0 }
//         };
//         const categorize = (status: string, category: 'Knowledge' | 'Practical' | 'Workplace') => {
//             const s = status?.toLowerCase() || '';
//             if (s === 'competent' || s === 'c' || s === 'pass') stats[category].Competent += 1;
//             else if (s === 'not yet competent' || s === 'nyc' || s === 'fail') stats[category].NYC += 1;
//             else stats[category].InProgress += 1;
//         };
//         activeLearners.forEach(l => {
//             l.knowledgeModules?.forEach(m => categorize(m.status, 'Knowledge'));
//             l.practicalModules?.forEach(m => categorize(m.status, 'Practical'));
//             l.workExperienceModules?.forEach(m => categorize(m.status, 'Workplace'));
//         });
//         return [
//             { name: 'Knowledge', ...stats.Knowledge },
//             { name: 'Practical', ...stats.Practical },
//             { name: 'Workplace', ...stats.Workplace }
//         ];
//     }, [activeLearners]);

//     const cohortLifecycleData = [
//         { name: 'Ongoing Classes', value: ongoingCohorts, color: 'var(--mlab-blue)' },
//         { name: 'Concluded Classes', value: concludedCohorts, color: 'var(--mlab-green)' },
//         { name: 'Upcoming Classes', value: upcomingCohorts, color: '#8b5cf6' }
//     ].filter(d => d.value > 0);

//     const web3Data = [
//         { name: 'Secured on Blockchain', value: securedCertificates, color: 'var(--mlab-green)' },
//         { name: 'Pending Mint', value: totalEnrollments - securedCertificates, color: '#f59e0b' }
//     ].filter(d => d.value > 0);

//     const tooltipStyle = {
//         borderRadius: '8px',
//         border: '1px solid var(--mlab-border)',
//         boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)',
//         fontFamily: 'var(--font-body)',
//         fontSize: '0.82rem',
//     };

//     return (
//         <div className="wm-root animate-fade-in" style={{ paddingBottom: '2rem' }}>

//             {/* ── PAGE HEADER (Reusing wm-page-header styling) ── */}
//             <div className="wm-page-header">
//                 <div className="wm-page-header__left">
//                     <div className="wm-page-header__icon"><LayoutDashboard size={22} /></div>
//                     <div>
//                         <h1 className="wm-page-header__title">System Overview</h1>
//                         <p className="wm-page-header__desc">High-level insights into academic performance, enrollments, and throughput.</p>
//                     </div>
//                 </div>
//             </div>

//             {/* ── KPI RIBBON ── */}
//             <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '1.25rem', marginBottom: '1.5rem' }}>
//                 <StatCard
//                     icon={<BookOpen size={20} />} title="Active Qualifications" value={activeProgrammesCount} borderColor="var(--mlab-blue)" />
//                 <StatCard icon={<Layers size={20} />} title="Active Cohorts" value={ongoingCohorts} borderColor="#8b5cf6" />
//                 <StatCard icon={<Users size={20} />} title="Total Enrollments" value={totalEnrollments} borderColor="var(--mlab-blue)" />
//                 <StatCard icon={<MapPin size={20} />} title="Active Delivery Sites" value={activeCampusesCount} borderColor="#f59e0b" />

//                 <StatCard icon={<GraduationCap size={20} />} title="EISA Admitted (Ready)" value={eisaReadyCount} borderColor="var(--mlab-green)" />
//                 <StatCard icon={<AlertTriangle size={20} />} title="At-Risk Learners" value={atRiskLearnersCount} borderColor="var(--mlab-red)" />

//                 <StatCard
//                     icon={<Scale size={20} />}
//                     title="Active Appeals"
//                     value={pendingAppealsCount}
//                     borderColor={pendingAppealsCount > 0 ? "var(--mlab-red)" : "var(--mlab-blue)"}
//                     onClick={() => { if (user?.role === 'admin' || user?.role === 'moderator') navigate('/moderation'); }}
//                     hoverable={user?.role === 'admin' || user?.role === 'moderator'}
//                 />

//                 <StatCard icon={<ShieldCheck size={20} />} title="Web3 Certificates Issued" value={securedCertificates} borderColor="#8b5cf6" />
//             </div>

//             {/* ── CHARTS ── */}
//             <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(450px, 1fr))', gap: '1.25rem' }}>

//                 {/* Formative Assessment Health */}
//                 <div className="wm-card">
//                     <div className="wm-card__header">
//                         <h3 className="wm-card__name" style={{ fontSize: '0.9rem' }}>Formative Assessment Health</h3>
//                     </div>
//                     <div style={{ padding: '1rem 1.1rem', height: '320px' }}>
//                         <ResponsiveContainer width="100%" height="100%">
//                             <BarChart data={assessmentData} margin={{ top: 5, right: 30, left: -20, bottom: 5 }}>
//                                 <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--mlab-border)" />
//                                 <XAxis dataKey="name" tick={{ fontSize: 12, fill: 'var(--mlab-grey)', fontFamily: 'var(--font-body)' }} axisLine={false} tickLine={false} />
//                                 <YAxis tick={{ fontSize: 12, fill: 'var(--mlab-grey)', fontFamily: 'var(--font-body)' }} axisLine={false} tickLine={false} />
//                                 <RechartsTooltip cursor={{ fill: 'var(--mlab-bg)' }} contentStyle={tooltipStyle} />
//                                 <Legend verticalAlign="top" height={36} iconType="circle" wrapperStyle={{ fontSize: '12px', fontFamily: 'var(--font-body)' }} />
//                                 <Bar dataKey="Competent" stackId="a" fill="var(--mlab-green)" radius={[0, 0, 4, 4]} />
//                                 <Bar dataKey="InProgress" stackId="a" fill="var(--mlab-blue)" name="In Progress" />
//                                 <Bar dataKey="NYC" stackId="a" fill="var(--mlab-red)" name="Not Yet Competent" radius={[4, 4, 0, 0]} />
//                             </BarChart>
//                         </ResponsiveContainer>
//                     </div>
//                 </div>

//                 {/* Enrollments by Location */}
//                 <div className="wm-card">
//                     <div className="wm-card__header">
//                         <h3 className="wm-card__name" style={{ fontSize: '0.9rem' }}>Enrollments by Location</h3>
//                     </div>
//                     <div style={{ padding: '1rem 1.1rem', height: '320px' }}>
//                         {campusData.length === 0 ? (
//                             <div style={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--mlab-grey-light)', fontStyle: 'italic', fontSize: '0.85rem' }}>
//                                 No active enrollments assigned to campuses.
//                             </div>
//                         ) : (
//                             <ResponsiveContainer width="100%" height="100%">
//                                 <BarChart data={campusData} margin={{ top: 5, right: 30, left: -20, bottom: 5 }}>
//                                     <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--mlab-border)" />
//                                     <XAxis dataKey="name" tick={{ fontSize: 12, fill: 'var(--mlab-grey)', fontFamily: 'var(--font-body)' }} axisLine={false} tickLine={false} />
//                                     <YAxis tick={{ fontSize: 12, fill: 'var(--mlab-grey)', fontFamily: 'var(--font-body)' }} axisLine={false} tickLine={false} />
//                                     <RechartsTooltip cursor={{ fill: 'var(--mlab-bg)' }} contentStyle={tooltipStyle} />
//                                     <Bar dataKey="learners" fill="#8b5cf6" radius={[4, 4, 0, 0]} maxBarSize={50} name="Active Learners" />
//                                 </BarChart>
//                             </ResponsiveContainer>
//                         )}
//                     </div>
//                 </div>

//                 {/* Cohort Lifecycle */}
//                 <div className="wm-card">
//                     <div className="wm-card__header">
//                         <h3 className="wm-card__name" style={{ fontSize: '0.9rem' }}>Cohort Lifecycle</h3>
//                     </div>
//                     <div style={{ padding: '1rem 1.1rem', height: '320px' }}>
//                         {cohortLifecycleData.length === 0 ? (
//                             <div style={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--mlab-grey-light)', fontStyle: 'italic', fontSize: '0.85rem' }}>
//                                 No active cohorts found.
//                             </div>
//                         ) : (
//                             <ResponsiveContainer width="100%" height="100%">
//                                 <PieChart>
//                                     <Pie data={cohortLifecycleData} cx="50%" cy="45%" innerRadius={70} outerRadius={100} paddingAngle={2} dataKey="value">
//                                         {cohortLifecycleData.map((entry, index) => (
//                                             <Cell key={`cell-${index}`} fill={entry.color} />
//                                         ))}
//                                     </Pie>
//                                     <RechartsTooltip contentStyle={tooltipStyle} />
//                                     <Legend verticalAlign="bottom" height={36} iconType="circle" wrapperStyle={{ fontFamily: 'var(--font-body)' }} />
//                                 </PieChart>
//                             </ResponsiveContainer>
//                         )}
//                     </div>
//                 </div>

//                 {/* Certification Status */}
//                 <div className="wm-card">
//                     <div className="wm-card__header">
//                         <h3 className="wm-card__name" style={{ fontSize: '0.9rem' }}>Certification Status</h3>
//                     </div>
//                     <div style={{ padding: '1rem 1.1rem', height: '320px' }}>
//                         {totalEnrollments === 0 ? (
//                             <div style={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--mlab-grey-light)', fontStyle: 'italic', fontSize: '0.85rem' }}>
//                                 No enrollments to certify yet.
//                             </div>
//                         ) : (
//                             <ResponsiveContainer width="100%" height="100%">
//                                 <PieChart>
//                                     <Pie data={web3Data} cx="50%" cy="45%" innerRadius={70} outerRadius={100} paddingAngle={2} dataKey="value">
//                                         {web3Data.map((entry, index) => (
//                                             <Cell key={`cell-${index}`} fill={entry.color} />
//                                         ))}
//                                     </Pie>
//                                     <RechartsTooltip contentStyle={tooltipStyle} />
//                                     <Legend verticalAlign="bottom" height={36} iconType="circle" wrapperStyle={{ fontFamily: 'var(--font-body)' }} />
//                                 </PieChart>
//                             </ResponsiveContainer>
//                         )}
//                     </div>
//                 </div>

//             </div>
//         </div>
//     );
// };
