import React, { useEffect, useRef, useState } from "react";
import { Trash2, Plus, X, AlertCircle } from "lucide-react";
import { CartesianPlane } from "@zakq/axisjs";

// ---------------------------------------------------------------------------
// Design tokens mapped to mLab CSS variables
// ---------------------------------------------------------------------------
const tokens = {
    border: "var(--mlab-border)",
    borderStrong: "var(--mlab-blue)",
    panelBg: "var(--mlab-light-blue)",
    ink: "var(--mlab-blue)",
    inkMuted: "var(--mlab-grey)",
    inkFaint: "var(--mlab-grey-lt)",
    danger: "var(--mlab-red)",
    dangerBg: "#fef2f2",
    accent: "var(--mlab-blue)",
    radius: 0, // Enforcing mLab square corners
};

// A small fixed palette so each row's dot on the canvas visually matches its
// row in the table. Cycles if there are more points than colors.
const POINT_COLORS = [
    "#ef4444", // red
    "#2563eb", // blue
    "#94c73d", // mLab green
    "#f59e0b", // amber
    "#a855f7", // purple
    "#0891b2", // cyan
];

export type PointRow = { x: string | number; y: string | number };

export interface AxisWorkspaceProps {
    value: { points?: PointRow[] } | undefined;
    onChange: (v: { points: PointRow[] }) => void;
    readOnly: boolean;
}

// Safely cast to string so `.trim()` doesn't crash on numbers
const isValidNumber = (v: string | number | undefined | null) => {
    if (v === null || v === undefined) return false;
    const str = String(v).trim();
    return str !== "" && !isNaN(parseFloat(str));
};

const AxisWorkspace: React.FC<AxisWorkspaceProps> = ({ value, onChange, readOnly }) => {
    const containerRef = useRef<HTMLDivElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const planeRef = useRef<CartesianPlane | null>(null);
    const rowRefs = useRef<Record<number, HTMLInputElement | null>>({});

    // Safety guard to auto-fit pre-filled database coordinates exactly once on initialization
    const isFirstLoadRef = useRef<boolean>(true);
    const [pendingFocusIndex, setPendingFocusIndex] = useState<number | null>(null);

    const points = value?.points || [];

    // -------------------------------------------------------------------
    // 1. Core Lifecycle Setup (Initialize Instance Exactly Once)
    // -------------------------------------------------------------------
    useEffect(() => {
        if (!canvasRef.current) return;

        // Initialize the tracking instance a single time on mount
        // autoFit is turned OFF to prevent camera jitter on every keystroke
        const plane = new CartesianPlane(canvasRef.current, {
            stepSequences: [1, 2, 5],
            autoFit: false,
        });
        planeRef.current = plane;

        const ro = new ResizeObserver(() => {
            plane.resize();
        });

        if (containerRef.current) {
            ro.observe(containerRef.current);
        }

        return () => {
            ro.disconnect();
            plane.destroy();
            planeRef.current = null;
        };
    }, []);

    // -------------------------------------------------------------------
    // 2. Live State Synchronization
    // -------------------------------------------------------------------
    useEffect(() => {
        const plane = planeRef.current;
        if (!plane) return;

        // Use the public API to clear existing points safely
        plane.clear();

        const validCoords: { x: number; y: number }[] = [];

        // Re-populate active elements
        points.forEach((p, i) => {
            const px = parseFloat(String(p.x));
            const py = parseFloat(String(p.y));
            if (!isNaN(px) && !isNaN(py)) {
                validCoords.push({ x: px, y: py });
                const color = POINT_COLORS[i % POINT_COLORS.length];
                plane.addPoint(px, py, color, `(${px}, ${py})`, true);
            }
        });

        // Trigger smooth camera animation on cold load if processing pre-filled data
        if (isFirstLoadRef.current && validCoords.length > 0) {
            isFirstLoadRef.current = false;
            setTimeout(() => {
                planeRef.current?.animateToFit(validCoords);
            }, 50);
        }
    }, [points]);

    // Focus the X input of a newly-added row once it exists in the DOM.
    useEffect(() => {
        if (pendingFocusIndex !== null) {
            rowRefs.current[pendingFocusIndex]?.focus();
            setPendingFocusIndex(null);
        }
    }, [pendingFocusIndex, points.length]);

    // -------------------------------------------------------------------
    // Row handlers
    // -------------------------------------------------------------------
    const updatePoint = (index: number, axis: "x" | "y", val: string) => {
        const newPoints = [...points];
        newPoints[index] = { ...newPoints[index], [axis]: val };
        onChange({ ...value, points: newPoints });
    };

    const removePoint = (index: number) => {
        const newPoints = points.filter((_, i) => i !== index);
        onChange({ ...value, points: newPoints });
    };

    const addPointRow = () => {
        const newPoints = [...points, { x: "", y: "" }];
        onChange({ ...value, points: newPoints });
        setPendingFocusIndex(newPoints.length - 1);

        // Trigger the smooth camera animation ONLY when adding a new row
        const plane = planeRef.current;
        if (plane) {
            const validCoords = points
                .map(p => ({ x: parseFloat(String(p.x)), y: parseFloat(String(p.y)) }))
                .filter(p => !isNaN(p.x) && !isNaN(p.y));

            if (validCoords.length > 0) {
                // Small timeout to ensure DOM updates settle before animating
                setTimeout(() => plane.animateToFit(validCoords), 50);
            }
        }
    };

    const handleClearGraph = () => {
        if (points.length === 0) return;
        if (points.length > 1 && !window.confirm(`Remove all ${points.length} points?`)) return;
        onChange({ ...value, points: [] });
    };

    // Pressing Enter in the Y field adds the next row and focuses it
    const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>, index: number) => {
        if (e.key === "Enter") {
            e.preventDefault();
            if (index === points.length - 1) {
                addPointRow();
            } else {
                rowRefs.current[index + 1]?.focus();
            }
        }
    };

    return (
        <div style={styles.wrapper}>
            {!readOnly && (
                <div style={styles.panel}>
                    <div style={styles.panelHeader}>
                        <span style={styles.panelTitle}>Coordinates</span>
                        <button
                            onClick={handleClearGraph}
                            disabled={points.length === 0}
                            style={{
                                ...styles.textButton,
                                ...(points.length === 0 ? styles.textButtonDisabled : {}),
                            }}
                            title="Clear all points"
                        >
                            <Trash2 size={13} />
                            Clear all
                        </button>
                    </div>

                    <div style={styles.rowList}>
                        {points.map((p, i) => {
                            const xValid = p.x === "" || isValidNumber(p.x);
                            const yValid = p.y === "" || isValidNumber(p.y);
                            const color = POINT_COLORS[i % POINT_COLORS.length];

                            return (
                                <div key={i} style={styles.row}>
                                    <span
                                        aria-hidden
                                        style={{ ...styles.colorDot, background: color }}
                                    />

                                    <label style={styles.fieldGroup}>
                                        <span style={styles.fieldPrefix}>X</span>
                                        <input
                                            ref={(el) => {
                                                rowRefs.current[i] = el;
                                            }}
                                            type="number"
                                            inputMode="decimal"
                                            value={p.x !== undefined ? p.x : ""}
                                            onChange={(e) => updatePoint(i, "x", e.target.value)}
                                            onKeyDown={(e) => handleKeyDown(e, i)}
                                            aria-label={`Point ${i + 1} X value`}
                                            placeholder="0"
                                            style={{
                                                ...styles.fieldInput,
                                                ...(xValid ? {} : styles.fieldInputInvalid),
                                            }}
                                            onFocus={(e) => (e.target.parentElement!.style.borderColor = tokens.borderStrong)}
                                            onBlur={(e) => (e.target.parentElement!.style.borderColor = tokens.border)}
                                        />
                                    </label>

                                    <label style={styles.fieldGroup}>
                                        <span style={styles.fieldPrefix}>Y</span>
                                        <input
                                            type="number"
                                            inputMode="decimal"
                                            value={p.y !== undefined ? p.y : ""}
                                            onChange={(e) => updatePoint(i, "y", e.target.value)}
                                            onKeyDown={(e) => handleKeyDown(e, i)}
                                            aria-label={`Point ${i + 1} Y value`}
                                            placeholder="0"
                                            style={{
                                                ...styles.fieldInput,
                                                ...(yValid ? {} : styles.fieldInputInvalid),
                                            }}
                                            onFocus={(e) => (e.target.parentElement!.style.borderColor = tokens.borderStrong)}
                                            onBlur={(e) => (e.target.parentElement!.style.borderColor = tokens.border)}
                                        />
                                    </label>

                                    <button
                                        onClick={() => removePoint(i)}
                                        style={styles.removeButton}
                                        aria-label={`Remove point ${i + 1}`}
                                        title="Remove point"
                                        onMouseEnter={(e) => { e.currentTarget.style.color = tokens.danger; }}
                                        onMouseLeave={(e) => { e.currentTarget.style.color = tokens.inkFaint; }}
                                    >
                                        <X size={14} />
                                    </button>
                                </div>
                            );
                        })}

                        {points.length === 0 && (
                            <div style={styles.emptyState}>
                                No points yet. Add one to start plotting.
                            </div>
                        )}
                    </div>

                    <button
                        onClick={addPointRow}
                        style={styles.addButton}
                        onMouseEnter={(e) => (e.currentTarget.style.background = "var(--mlab-blue-dark)")}
                        onMouseLeave={(e) => (e.currentTarget.style.background = "var(--mlab-blue)")}
                    >
                        <Plus size={14} />
                        Add point
                    </button>

                    {points.some((p) => (p.x !== "" && !isValidNumber(p.x)) || (p.y !== "" && !isValidNumber(p.y))) && (
                        <div style={styles.warning}>
                            <AlertCircle size={13} style={{ flexShrink: 0 }} />
                            <span>Points with invalid numbers won't be plotted.</span>
                        </div>
                    )}
                </div>
            )}

            <div style={styles.canvasColumn}>
                <div ref={containerRef} style={styles.canvasContainer}>
                    <canvas ref={canvasRef} style={styles.canvas} />
                </div>
                <span style={styles.hint}>Drag to pan · scroll to zoom</span>
            </div>
        </div>
    );
};

// ---------------------------------------------------------------------------
// Styles matching mLab definitions
// ---------------------------------------------------------------------------
const styles: Record<string, React.CSSProperties> = {
    wrapper: {
        display: "flex",
        gap: 16,
        flexDirection: "row",
        flexWrap: "wrap",
    },
    panel: {
        width: 280,
        flex: "1 1 280px",
        maxWidth: 320,
        display: "flex",
        flexDirection: "column",
        gap: 10,
        background: tokens.panelBg,
        padding: "1rem",
        border: `1px solid ${tokens.border}`,
        borderLeft: `4px solid ${tokens.borderStrong}`,
        borderRadius: tokens.radius,
    },
    panelHeader: {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        borderBottom: `2px solid ${tokens.borderStrong}`,
        paddingBottom: "0.5rem",
        marginBottom: "0.25rem",
    },
    panelTitle: {
        fontFamily: "var(--font-heading)",
        fontSize: "0.72rem",
        fontWeight: 700,
        letterSpacing: "0.16em",
        textTransform: "uppercase",
        color: tokens.ink,
    },
    textButton: {
        display: "flex",
        alignItems: "center",
        gap: 4,
        background: "transparent",
        border: "none",
        padding: "4px 6px",
        fontFamily: "var(--font-body)",
        fontSize: "0.75rem",
        fontWeight: 600,
        color: tokens.danger,
        cursor: "pointer",
        outline: "none",
    },
    textButtonDisabled: {
        color: tokens.inkFaint,
        cursor: "not-allowed",
    },
    rowList: {
        display: "flex",
        flexDirection: "column",
        gap: 8,
        maxHeight: 420,
        overflowY: "auto",
        paddingRight: 4,
    },
    row: {
        display: "flex",
        gap: 8,
        alignItems: "center",
        background: "var(--mlab-white)",
        padding: "6px 8px",
        borderRadius: tokens.radius,
        border: `1px solid ${tokens.border}`,
    },
    colorDot: {
        width: 10,
        height: 10,
        borderRadius: "50%",
        flexShrink: 0,
    },
    fieldGroup: {
        display: "flex",
        alignItems: "center",
        background: "var(--mlab-white)",
        border: `1px solid ${tokens.border}`,
        borderRadius: tokens.radius,
        overflow: "hidden",
        transition: "border-color 0.15s",
    },
    fieldPrefix: {
        padding: "4px 8px",
        fontFamily: "var(--font-heading)",
        fontSize: "0.68rem",
        fontWeight: 600,
        letterSpacing: "0.12em",
        textTransform: "uppercase",
        color: tokens.inkMuted,
        borderRight: `1px solid ${tokens.border}`,
        background: "var(--mlab-bg)",
    },
    fieldInput: {
        width: 60,
        border: "none",
        background: "transparent",
        padding: "4px 6px",
        fontFamily: "var(--font-body)",
        fontSize: "0.85rem",
        color: tokens.ink,
        outline: "none",
    },
    fieldInputInvalid: {
        background: tokens.dangerBg,
        color: tokens.danger,
    },
    removeButton: {
        background: "transparent",
        border: "none",
        color: tokens.inkFaint,
        cursor: "pointer",
        padding: 4,
        marginLeft: "auto",
        borderRadius: tokens.radius,
        transition: "color 0.15s ease",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
    },
    emptyState: {
        textAlign: "center",
        padding: "1.5rem 0.5rem",
        color: tokens.inkMuted,
        fontFamily: "var(--font-body)",
        fontSize: "0.8rem",
    },
    addButton: {
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        gap: 6,
        width: "100%",
        padding: "0.6rem 1.25rem",
        background: tokens.accent,
        color: "var(--mlab-white)",
        border: "none",
        borderRadius: tokens.radius,
        fontFamily: "var(--font-heading)",
        fontSize: "0.72rem",
        fontWeight: 700,
        letterSpacing: "0.1em",
        textTransform: "uppercase",
        cursor: "pointer",
        transition: "background 0.15s",
        marginTop: "4px",
    },
    warning: {
        display: "flex",
        alignItems: "center",
        gap: 6,
        fontFamily: "var(--font-body)",
        fontSize: "0.75rem",
        color: "#b45309",
        background: "#fffbeb",
        border: "1px solid #fde68a",
        borderRadius: tokens.radius,
        padding: "8px 10px",
    },
    canvasColumn: {
        flex: "3 1 320px",
        minWidth: 300,
        display: "flex",
        flexDirection: "column",
        gap: 8,
    },
    canvasContainer: {
        position: "relative",
        width: "100%",
        height: 500,
        borderRadius: tokens.radius,
        overflow: "hidden",
        border: `2px solid ${tokens.borderStrong}`,
        background: "var(--mlab-white)",
    },
    canvas: {
        position: "absolute",
        top: 0,
        left: 0,
        width: "100%",
        height: "100%",
        display: "block",
    },
    hint: {
        fontFamily: "var(--font-body)",
        fontSize: "0.75rem",
        color: tokens.inkMuted,
    },
};

export default AxisWorkspace;